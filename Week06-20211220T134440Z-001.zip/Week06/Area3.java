package Week06;

public class Area3 {
    public static void main(String[] args) {

        int hight = 15;
        int base = 20;
        // final float x = 0.5f;

        double result = (1 / 2d) * base * hight;

        System.out.println("Result : " + result);

    }
}
