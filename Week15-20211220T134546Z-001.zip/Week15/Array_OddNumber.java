package Week15;

public class Array_OddNumber {
    public static void main(String[] args) {
        int [] n = {1,3,5,7,9,11,13,15,17,19};

        for (int i = 0; i < n.length; i++) {
            System.out.println(n[i]);
        }
    }
}
