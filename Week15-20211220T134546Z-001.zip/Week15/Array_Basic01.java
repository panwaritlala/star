package Week15;

public class Array_Basic01 {
    public static void main(String[] args) {
       long [] num = new long [200];   // แบบ 2
      // long [] num = {1,2,3,4,5,6,7,8,9,2,2,2,3,3,3,34,4};  // แบบ 1

       int [] dice = {1,2,3,4,5,6};
     //  int [] dice = new int [6];

       float [] avgGrade = new float [451];
     //  float [] avgGrade = {1.30f,2.02f,3.22f,4.00f,1.05f,2.06f} //กรอกให้ครบ 451 ตัว

       char [] grade = new char [369];
      // char [] grade = {'A','B','C','A','B','B','C','E'};//กรอกให้ครบ 369  ตัว






    }
}
