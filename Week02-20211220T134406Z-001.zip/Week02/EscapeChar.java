package Week02;
public class EscapeChar {
    public static void main(String[] args) {
        System.out.print("*\n**\n***\n****\n*****\n"+"****\n***\n**\n*");
    }
    
}
