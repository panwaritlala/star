package Week02;
public class Comment {   // Start of Class
    public static void main(String[] args) {  // Start of method
        // ส่วนของการแสดงผล

       
        System.out.println("Comment");    // display
        System.out.println("   - Single comment");   // display 2
        System.out.println("   - Multiple comment");   // display 3
 

        System.out.println("หนูทำได้แล้ว เย้");


    }  //End of method
}  // End of Class


