package Week02;
/*
     Program name = HelloWorld
     Create by =  Suksawat
     Date = 16/7/2564

*/

class HelloWorld {
    public static void  main(String[] args) {

        // การแสดงผลออกหน้าจอ 

        System.out.println("Welcome to my First Program");  
        System.out.println("==========================="); 
        System.out.println("Name: สุขสวัสดิ์  แซ่่ลิ่ม");
        System.out.println("Age : 45");
        System.out.println("University : NPRU");

     


        
    }  // End of method

}  // End of class