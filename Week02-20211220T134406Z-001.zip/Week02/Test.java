package Week02;

public class Test { 
    public static void main (String args[])  {
        System.out.println("Test Java"); 
    } //End of main
}  //End of class

