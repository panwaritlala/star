package Week02;

public class EscapeCharacters {
    public static void main (String[] atgs) {   
        // using newline (\n)
        System.out.print("Today, I went to a beach.\n");
        System.out.print("I see a lot of people in this\nweekend.");
        System.out.print("\n");
        // using tab (\t)
        System.out.println("MateoCode\ttutorials");
        System.out.println("is the best\ttutorial.");
    }

}
