package Week03;

public class DataType {
    public static void main(String[] args) {
        int x = 5; // ประกาศตัวแปร x เป็นจำนวนเต็ม และกำหนดค่า x = 5
        double y = 3.1000; // ประกาศตัวแปร y เป็นเลขทศนิยม และกำหนดค่า y = 3.1000
        double z = 0;
        z = y + x;
        System.out.println("z=" + (y + x));
    }
}
