package Week03;
public class Strings{
    public static void main(String[] args) {
        System.out.println("xxxxx");
    }
} 
