package Week03;

public class RangOfData {
    public static void main(String[] args) {
        System.out.println("Data type of byte => \tMax = " + Byte.MAX_VALUE + "\t\t\tMin = " + Byte.MIN_VALUE);
        System.out.println("Data type of short => \tMax = " + Short.MAX_VALUE + "\t\t\tMin = " + Short.MIN_VALUE);
        System.out.println("Data type of int => \tMax = " + Integer.MAX_VALUE + "\t\tMin = " + Integer.MIN_VALUE);
        System.out.println("Data type of long => \tMax = " + Long.MAX_VALUE + "\tMin = " + Long.MIN_VALUE);
        System.out.println("Data type of double => \tMax = " + Double.MAX_VALUE + "\tMin = " + Double.MIN_VALUE);
        System.out.println("Data type of float => \tMax = " + Float.MAX_VALUE + "\t\tMin = " + Float.MIN_VALUE);

    }
}
