package Week17;

public class Test01 {
    static void myMethod() {
        System.out.println("Hello Java");
    }

    public static void main(String[] args) {
        myMethod();
        myMethod();
        myMethod();
    }
}
