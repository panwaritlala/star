package Week12;

public class DoWhile01 {
    public static void main(String[] args) {
        // Output   1  2  3  4  5
        int i = 1;
        do {
            System.out.print(i + " ");
            i++;
        } while (i<=5);

        System.out.println();

        int j =1;
        while (j<=5) {
            System.out.print(j+ " ");
            j++;
        }
    }
}
