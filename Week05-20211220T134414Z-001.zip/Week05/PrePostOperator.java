package Week05;

public class PrePostOperator {
    public static void main(String[] args) {
        // declare variable
        int x = 5, y = 4;
        // x= x+1;
        x += 1;

        System.out.println("ans = " + x);

    }
}
