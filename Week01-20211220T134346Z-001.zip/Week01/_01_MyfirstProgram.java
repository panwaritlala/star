package Week01;

class _01_MyfirstProgram{
    public static void main(String [] args){
        System.out.println("Welcome to Java Programming");
        System.out.println("My name is Suksawat");

    }
}
