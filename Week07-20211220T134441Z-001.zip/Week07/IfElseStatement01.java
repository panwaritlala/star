package Week07;

public class IfElseStatement01 {
    public static void main(String[] args) {
        char gender = 'b';

        if (gender != 'b') {
            System.out.println("Boy");
        } else {
            System.out.println("Girl");
        }

    }
}
