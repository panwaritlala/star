package Week07;

public class IfElseStatement02 {
    public static void main(String[] args) {
        int age = 18;
        // เขียนด้วยคำสั่ง if .... else....
        if (age >= 15) {
            System.out.println("man/women");
        } else {
            System.out.println("boy/girl");
        }

        // เขียนด้วยคำสั่ง If อย่างเดียว
        // if (age<15) {
        // System.out.println("boy/girl");
        // }
        // if (age>=15) {
        // System.out.println("man/woman");
        // }
        System.out.println("End of Program");
    }
}
