package Week11;

public class While_DecreaseNumber {
    public static void main(String[] args) {
        int count = 20;
        while (count >= 10) {
            System.out.print(count+" ");
            count--;
        }
    }
}
