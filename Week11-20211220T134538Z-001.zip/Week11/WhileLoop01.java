package Week11;

public class WhileLoop01 {
    public static void main(String[] args) {
        int count=1;
        while (count<=10) {
            // System.out.println("Hello World");
            System.out.println("รอบที่ "+count+" Hello World");
            count++;
        }
    }
}
