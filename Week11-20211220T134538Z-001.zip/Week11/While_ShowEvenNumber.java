package Week11;

public class While_ShowEvenNumber {
    public static void main(String[] args) {
        int count = 1;
        while (count < 11) {
            System.out.print(count*2 +" ");
            count++;
        }

        // int count = 2;
        // while (count <= 20) {
        //     System.out.print(count +" ");
        //     count+=2;  //count = count+2
        // }
    }
}
