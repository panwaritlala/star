package Week11;

public class ForLoop01 {
    public static void main(String[] args) {
        // 3 ส่วน
        // ส่วนตัวแปรเริ่มต้น
        // เงื่อนไข
        // การเพิ่มค่า / การลดค่า

        for (int i = 1; i <= 10; i++) {
            // System.out.println("Hello World");
            // System.out.println(i);
            System.out.println("รอบที่ " + i + " Hello World");
        }
    }
}
