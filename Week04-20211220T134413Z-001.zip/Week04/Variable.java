package Week04;

public class Variable {
    public static void main(String[] args) {
        String name = "Suksawat";
        int age = 18;
        String nickname = "kaow";
        float weight = 65;
        String id = "644230035";
        String pet = "dog";
        int yearOld = 10;
        String number = "285";
        String year = "2002";
        // String number = "285"; // ชื่อตัวแปรซ้ำ ไม่ได้
        // String year=10;
        String province = "ratchaburi";
        String hi = "HELLO";
        String studyGroup = "64/38";
        double money = 300;
        String lastname = "Lonu";
        String favorite_food = "Pizza";
        float height = 170f;
        String favorite_game = "Genshin impact";
        byte amount = 2;
        String birthday = "31/10/45";
        double number01 = 1.0D;
        int amountOfPhone = 1;
        String temperture = "32";
        String day = "Friday";
        String phoneNumber = "191";
        boolean status = true;

        System.out.println("Name: " + name + " Lastname: " + lastname + " Age: " + age);
    }
}
